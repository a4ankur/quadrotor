var handleLaunch = function(consoleElement) {
	consoleElement.innerHTML = 'response\n' + consoleElement.innerHTML;
}
